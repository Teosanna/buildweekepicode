									Progetto Buildweek 1 "Benchmark Epicode"


Gruppo 5

Chris Martina
Matteo Sanna
Aurelio Marco Giglia
Emiliano Mondaini


Progetto affrontato a 8 mani, con la divisione della squadra in due microgruppi, Matteo e Aurelio la parte html e css, e in aiuto per il codice del Javascript.
Emiliano e Chris, dedicati al codice JS.
Il gruppo ha utilizzato le repository di GitHub, tenendoci in contatto con il gruppo whatsApp creato apposta per il compito.
Durante il giorno chi poteva, si dedicava al proprio codice, avvisando il resto del gruppo di eventuali difficoltà riscontrate o dubbi sulla stesura.
Spesso ogni componente del gruppo si è dedicato per l'aiuto del proprio collega, soprattutto nella parte più difficoltosa, lo sviluppo del JS.
Facevamo breafing su come realizzare parti di codice, e fino a notte tarda per risolvere problematiche e bug eventuali.
L'impegno del gruppo è stato coeso e sempre cooperativo.
in primis realizzato lo scheletro diviso in 4 fogli, e 2 di css(compreso il normalize).
Emiliano e Chris hanno svolto anche con aiuto di Matteo e Aurelio, il codice di javascript, provando e riprovando e cercando di creare piccole parti di codice, soprattutto utilizzando i programmi come CodePen, e cercando poi di assemblare e farlo funzionare.
Il gruppo 5 si è dato una tempistica per la realizzazione del compito, con checkout giornalieri e relazioni orali via Discord.
Tranquillità e spirito di gruppo hanno tracciato una linea importante per la realizzazzione del progetto.
Lo studio di ogni elemento del team, fatto a livello personale, è stato degno di nota.




Difficoltà riscontrate:

Relaizzazione timer,dapprima con librerie e poi rivisitato con css e Js.
Realizzazione Feedback, in quanto sembrava semplice ma nascondeva molte insidie.
Posizionamneto sul viewport di oggetti e scritte.
Nel Javascript insidie legate alla quantità di dati da far emergere e dal loro funzionamento.

Io, Emiliano Mondaini da referente del gruppo 5, volevo fare i complimentti al mio gruppo, per la loro sensibilità e la loro presenza attiva non scontata, e poichè da subito ci è mancato un elemento, che non essendosi presentato, ha spiazzato l'organigramma lavorativo, facendo zoppicare la struttura, ma da subito il gruppo ha reagito positivamente.
